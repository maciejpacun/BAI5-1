# BAI5

Application for the PATIENT so that he can sign up for a visit to the doctor's office.
Website content and functions:
- calendar
- the possibility of booking a visit
- information about the clinic - subpage with a map
- settings: language / darkmode / first day of the week
- FAQ: f.e. how to cancel an appointment
- send a confirmation e-mail, save in the calendar


# Figma Link

https://www.figma.com/file/laxnlbVbQPt0DFpjQXk2rT/Untitled?type=design&t=eB6QGu7VcsP3UHR4-6



# Jak ściągnąć repo, na swój vscode

1. Otworzyć pusty vscode.
2. kliknąć ![image](https://github.com/KarolSzeliga4/BAI5/assets/63848317/8a11f3bc-6f2d-476f-aa53-92a519d26aae)
3. kliknąć "clone repo" i wpisać https://github.com/KarolSzeliga4/BAI5.git
4. https://nodejs.org/en/download ściągnąć nodejsa
5. otworzyć terminal (w vscodzie) i wpisać: 'npm install vite', potem 'cd bookuj' i 'npm run dev'
6. można działać z frontem
